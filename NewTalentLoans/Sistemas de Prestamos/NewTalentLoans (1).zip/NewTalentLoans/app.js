/* New Talent Loans v1.01 - datos en localStorage (capa DB lista para migrar a MySQL) */
const $=s=>document.querySelector(s),e=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const RD=n=>'RD$ '+(+n||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
const hoy=()=>new Date().toISOString().slice(0,10),gid=p=>p+Math.random().toString(36).slice(2,8);
const addM=(d,k)=>{const x=new Date(d+'T12:00');x.setMonth(x.getMonth()+k);return x.toISOString().slice(0,10)};
const dias=d=>Math.max(0,Math.floor((new Date(hoy()+'T12:00')-new Date(d+'T12:00'))/864e5));
const dg=b=>{let s=0;for(let i=0;i<10;i++){const p=+b[i]*(i%2?2:1);s+=p>9?p-9:p}return(10-s%10)%10};
const cedOK=c=>{c=c.replace(/\D/g,'');return c.length==11&&dg(c)==+c[10]};
const mkCed=b=>{const c=b+dg(b);return c.slice(0,3)+'-'+c.slice(3,10)+'-'+c[10]};
const telOK=t=>/^(809|829|849)-?\d{3}-?\d{4}$/.test(t),mailOK=m=>/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(m);
const enc=s=>btoa(unescape(encodeURIComponent(s)));
let DB=JSON.parse(localStorage.ntl||'null');
const save=()=>localStorage.ntl=JSON.stringify(DB);
const U=()=>DB.users.find(u=>u.email==sessionStorage.ntl_s);
const log=a=>{DB.log.unshift({f:new Date().toLocaleString('es-DO'),u:U()?.nombre||'Sistema',a});DB.log=DB.log.slice(0,100);save()};
/* ---- negocio ---- */
const cuotaF=(P,t,n)=>{const r=t/100;return r?P*r/(1-Math.pow(1+r,-n)):P/n};
function plan(P,t,n,f0){let s=P,c=cuotaF(P,t,n),o=[];for(let i=1;i<=n;i++){const it=s*t/100,cp=i==n?s:c-it;s-=cp;o.push({n:i,fecha:addM(f0,i),cuota:+(cp+it).toFixed(2),interes:+it.toFixed(2),capital:+cp.toFixed(2),saldo:+Math.max(s,0).toFixed(2),pag:0,mp:0})}return o}
const moraC=c=>c.fecha<hoy()?Math.max(0,+((c.cuota-c.pag)*DB.cfg.mora/3000*dias(c.fecha)-c.mp).toFixed(2)):0;
const sal=p=>p.plan.reduce((a,c)=>a+c.cuota-c.pag,0),morP=p=>p.plan.reduce((a,c)=>a+moraC(c),0);
const cli=id=>DB.clientes.find(c=>c.id==id)||{nombre:'?',apellido:''},nom=c=>c.nombre+' '+c.apellido;
function nuevoP(d){const p={id:gid('p'),num:'PR-'+String(DB.seq.p++).padStart(4,'0'),estado:'Pendiente',fsol:hoy(),plan:[],...d};DB.prestamos.push(p);save();return p}
function aprobar(id,f=hoy()){const p=DB.prestamos.find(x=>x.id==id);p.estado='Activo';p.fdes=f;p.plan=plan(p.monto,p.tasa,p.n,f);log('Aprobó y desembolsó '+p.num);save()}
function pagar(id,m,met){const p=DB.prestamos.find(x=>x.id==id);let r=m,mo=0;
for(const c of p.plan){const t=Math.min(r,moraC(c));c.mp=+(c.mp+t).toFixed(2);r-=t;mo+=t}
for(const c of p.plan){const t=Math.min(r,c.cuota-c.pag);c.pag=+(c.pag+t).toFixed(2);r-=t}
if(sal(p)<.01){p.estado='Saldado';p.plan.forEach(c=>c.pag=c.cuota)}
const x={id:'REC-'+String(DB.seq.r++).padStart(5,'0'),pid:id,f:hoy(),monto:m,mora:+mo.toFixed(2),met,u:U()?.nombre||'Sistema'};DB.pagos.push(x);log('Pago '+x.id+' de '+p.num);save();return x}
function seed(){DB={cfg:{empresa:'New Talent Loans',mora:4,tipos:[{n:'Personal',t:3},{n:'Comercial',t:2.5},{n:'Vehículo',t:2},{n:'Hipotecario',t:1.5}]},seq:{p:1,r:1},
users:[{nombre:'Administrador',email:'admin@ntl.do',pass:enc('admin123'),rol:'Administrador'},{nombre:'Carlos Oficial',email:'oficial@ntl.do',pass:enc('oficial123'),rol:'Oficial'},{nombre:'Ana Cajera',email:'cajero@ntl.do',pass:enc('cajero123'),rol:'Cajero'},{nombre:'María Pérez',email:'maria@correo.com',pass:enc('cliente123'),rol:'Cliente'}],
clientes:[{id:'c1',nombre:'María',apellido:'Pérez',ced:mkCed('0011234567'),tel:'809-555-0101',email:'maria@correo.com',dir:'San Pedro de Macorís',ocup:'Comerciante',ing:45000,gar:'Juan Pérez 829-555-0102',fecha:hoy()},
{id:'c2',nombre:'José',apellido:'Martínez',ced:mkCed('0230012345'),tel:'829-555-0202',email:'jose@correo.com',dir:'Santo Domingo',ocup:'Chofer',ing:30000,gar:'Rosa Díaz 849-555-0203',fecha:hoy()},
{id:'c3',nombre:'Luisa',apellido:'Gómez',ced:mkCed('4020987654'),tel:'849-555-0303',email:'luisa@correo.com',dir:'La Romana',ocup:'Docente',ing:38000,gar:'',fecha:hoy()}],prestamos:[],pagos:[],log:[]};
const a=nuevoP({cid:'c1',tipo:'Personal',monto:50000,tasa:3,n:12,gar:'Pagaré notarial'});aprobar(a.id,addM(hoy(),-3));pagar(a.id,a.plan[0].cuota,'Efectivo');
const b=nuevoP({cid:'c2',tipo:'Vehículo',monto:120000,tasa:2,n:24,gar:'Matrícula vehículo'});aprobar(b.id,addM(hoy(),-4));
nuevoP({cid:'c3',tipo:'Personal',monto:25000,tasa:3,n:10,gar:''});DB.log=[];save()}
if(!DB)seed();
/* ---- UI común ---- */
const O=(a,f)=>a.map(f).join(''),L=(n,l,v='',t='text',x='')=>`<label>${l}<input name=${n} type=${t} value="${e(v)}" ${x}></label>`;
const T=(h,r)=>`<div class=tw><table><tr>${O(h,x=>`<th>${x}</th>`)}</tr>${O(r,x=>`<tr>${O(x,y=>`<td>${y}</td>`)}</tr>`)||`<tr><td colspan=${h.length}>Sin registros</td></tr>`}</table></div>`;
const M=h=>{$('#m').innerHTML=h;$('#m').showModal()},X=()=>$('#m').close(),fd=ev=>{ev.preventDefault();return Object.fromEntries(new FormData(ev.target))};
const tag=s=>`<span class="tag ${s}">${s}</span>`,can=()=>['Administrador','Oficial'].includes(U().rol),staff=()=>U().rol!='Cliente',myC=()=>DB.clientes.find(c=>c.email==U().email);
const mine=()=>staff()?DB.prestamos:DB.prestamos.filter(p=>p.cid==myC()?.id);
const MODS={inicio:['Inicio','home'],panel:['Panel Principal','panel'],clientes:['Clientes','clientes'],prestamos:['Préstamos','prestamos'],pagos:['Pagos','pagos'],reportes:['Reportes','reportes'],config:['Configuración','config']};
const ic=k=>`<img src=assets/${MODS[k][1]}.png alt="">`;
const ROL={Administrador:Object.keys(MODS),Oficial:['inicio','panel','clientes','prestamos','reportes'],Cajero:['inicio','panel','clientes','pagos'],Cliente:['inicio','prestamos','pagos']};
const out=()=>{log('Cierre de sesión');sessionStorage.removeItem('ntl_s');location='index.html'};
function initApp(){const u=U();if(!u)return location='index.html';$('#un').textContent=u.nombre;$('#ln').textContent=u.nombre;
$('#nav').innerHTML=O(ROL[u.rol],k=>`<a href="#${k}" data-k=${k}>${ic(k)}<span>${MODS[k][0]}</span></a>`);$('#logo').onclick=()=>$('.app').classList.toggle('mini');addEventListener('hashchange',render);render()}
function render(){const k=location.hash.slice(1)||'inicio';if(!ROL[U().rol].includes(k))return location.hash='inicio';
$('.app').classList.toggle('home',k=='inicio');$('#main').innerHTML=V[k]();document.querySelectorAll('#nav a').forEach(a=>a.classList.toggle('on',a.dataset.k==k));({clientes:lc,prestamos:lp,pagos:lg,reportes:rp}[k]||(()=>0))()}
const V={};
V.inicio=()=>`<p class=wl>¡Bienvenidos(a), “${e(U().nombre)}” al Sistema de Préstamos New Talent Loans!</p><fieldset class=tiles><legend>Área de Servicios</legend>${O(ROL[U().rol].filter(k=>k!='inicio'),k=>`<a href="#${k}" class=tile>${ic(k)}<b>${MODS[k][0]}</b></a>`)}</fieldset>`;
V.panel=()=>{const A=DB.prestamos.filter(p=>p.estado=='Activo'),mes=hoy().slice(0,7),cob=DB.pagos.filter(x=>x.f.startsWith(mes)).reduce((a,x)=>a+x.monto,0);
const prox=A.flatMap(p=>p.plan.filter(c=>c.cuota-c.pag>.005).slice(0,1).map(c=>[p,c])).sort((a,b)=>a[1].fecha<b[1].fecha?-1:1).slice(0,8);
const ms=[...Array(6)].map((_,i)=>{const k=addM(hoy().slice(0,8)+'01',i-5).slice(0,7);return[k,DB.pagos.filter(x=>x.f.startsWith(k)).reduce((a,x)=>a+x.monto,0)]}),mx=Math.max(...ms.map(m=>m[1]),1);
return `<h2>Panel Principal</h2><div class=kp>${O([['Clientes',DB.clientes.length],['Préstamos activos',A.length],['Cartera pendiente',RD(A.reduce((a,p)=>a+sal(p),0))],['Cobrado este mes',RD(cob)],['Mora acumulada',RD(A.reduce((a,p)=>a+morP(p),0))],['Solicitudes pendientes',DB.prestamos.filter(p=>p.estado=='Pendiente').length]],k=>`<div class=card><small>${k[0]}</small><b>${k[1]}</b></div>`)}</div>
<h3>Cobros últimos 6 meses</h3><div class=ch>${O(ms,m=>`<div><i style="height:${m[1]/mx*100}%"></i><span>${m[0]}</span><small>${RD(m[1])}</small></div>`)}</div>
<h3>Próximos vencimientos</h3>${T(['Préstamo','Cliente','Cuota','Fecha','Monto','Estado'],prox.map(([p,c])=>[p.num,e(nom(cli(p.cid))),c.n,c.fecha,RD(c.cuota-c.pag),c.fecha<hoy()?tag('Rechazado').replace('Rechazado','Atrasada'):tag('Activo').replace('Activo','Al día')]))}`};
/* ---- clientes ---- */
V.clientes=()=>`<div class=bar><h2>Clientes</h2><input id=q placeholder="Buscar nombre o cédula" oninput=lc()><button onclick=fc()>+ Nuevo cliente</button></div><div id=lst></div>`;
const lc=()=>{const q=($('#q').value||'').toLowerCase();$('#lst').innerHTML=T(['Nombre','Cédula','Teléfono','Correo','Ingreso','Préstamos',''],DB.clientes.filter(c=>(nom(c)+c.ced).toLowerCase().includes(q)).map(c=>[e(nom(c)),e(c.ced),e(c.tel),e(c.email),RD(c.ing),DB.prestamos.filter(p=>p.cid==c.id).length,`<button onclick="vc('${c.id}')">Ver</button><button class=s onclick="fc('${c.id}')">Editar</button>`+(U().rol=='Administrador'?`<button class=d onclick="dc('${c.id}')">Eliminar</button>`:'')]))};
function fc(id){const c=DB.clientes.find(x=>x.id==id)||{};M(`<h3>${id?'Editar':'Nuevo'} cliente</h3><form class=g onsubmit="sc(event,'${id||''}')">${L('nombre','Nombre',c.nombre,'text','required')}${L('apellido','Apellido',c.apellido,'text','required')}${L('ced','Cédula (000-0000000-0)',c.ced,'text','required')}${L('tel','Teléfono (809-000-0000)',c.tel,'text','required')}${L('email','Correo',c.email,'email')}${L('dir','Dirección',c.dir)}${L('ocup','Ocupación',c.ocup)}${L('ing','Ingreso mensual RD$',c.ing,'number','min=0')}${L('gar','Garante (nombre y teléfono)',c.gar)}<div class=bt><button type=button class=s onclick=X()>Cancelar</button><button>Guardar</button></div></form>`)}
function sc(ev,id){const d=fd(ev);if(!cedOK(d.ced))return alert('Cédula inválida (verifique los 11 dígitos).');if(!telOK(d.tel))return alert('Teléfono inválido. Use 809/829/849-000-0000.');
if(d.email&&!mailOK(d.email))return alert('Correo inválido.');const n=s=>s.replace(/\D/g,'');if(DB.clientes.some(c=>n(c.ced)==n(d.ced)&&c.id!=id))return alert('Ya existe un cliente con esa cédula.');
d.ing=+d.ing||0;if(id)Object.assign(DB.clientes.find(c=>c.id==id),d);else DB.clientes.push({id:gid('c'),fecha:hoy(),...d});log((id?'Editó':'Creó')+' cliente '+d.nombre+' '+d.apellido);save();X();lc()}
function dc(id){if(DB.prestamos.some(p=>p.cid==id))return alert('No se puede eliminar: el cliente tiene préstamos registrados.');if(!confirm('¿Eliminar cliente?'))return;DB.clientes=DB.clientes.filter(c=>c.id!=id);log('Eliminó cliente');save();lc()}
function vc(id){const c=cli(id),P=DB.prestamos.filter(p=>p.cid==id);M(`<h3>${e(nom(c))}</h3><p>Cédula: ${e(c.ced)} · Tel: ${e(c.tel)} · ${e(c.email)}<br>${e(c.dir)} · ${e(c.ocup)} · Ingreso ${RD(c.ing)}<br>Garante: ${e(c.gar)||'N/A'}</p>${T(['Nº','Monto','Estado','Saldo'],P.map(p=>[p.num,RD(p.monto),tag(p.estado),p.estado=='Activo'?RD(sal(p)):'-']))}<div class=bt><button class=s onclick=X()>Cerrar</button></div>`)}
/* ---- préstamos ---- */
V.prestamos=()=>`<div class=bar><h2>Préstamos</h2><select id=fe onchange=lp()><option value="">Todos</option>${O(['Pendiente','Activo','Saldado','Rechazado'],s=>`<option>${s}</option>`)}</select><button onclick=fp()>${staff()?'+ Nuevo préstamo':'Solicitar préstamo'}</button></div><div id=lst></div>`;
const lp=()=>{const f=$('#fe').value;$('#lst').innerHTML=T(['Nº','Cliente','Monto','Tasa/mes','Cuotas','Estado','Saldo','Mora',''],mine().filter(p=>!f||p.estado==f).map(p=>[p.num,e(nom(cli(p.cid))),RD(p.monto),p.tasa+'%',p.n,tag(p.estado),p.estado=='Activo'?RD(sal(p)):'-',p.estado=='Activo'?RD(morP(p)):'-',`<button onclick="vp('${p.id}')">Ver</button>`+(p.estado=='Pendiente'&&can()?`<button onclick="ap('${p.id}')">Aprobar</button><button class=d onclick="rj('${p.id}')">Rechazar</button>`:'')]))};
function fp(){const cl=staff()?null:myC();if(!staff()&&!cl)return alert('Su cuenta no tiene ficha de cliente.');
M(`<h3>${staff()?'Nuevo préstamo':'Solicitud de préstamo'}</h3><form class=g oninput=sim(this) onsubmit=sp(event)>${staff()?`<label>Cliente<select name=cid>${O(DB.clientes,c=>`<option value=${c.id}>${e(nom(c))} - ${e(c.ced)}</option>`)}</select></label>`:`<input type=hidden name=cid value=${cl.id}>`}<label>Tipo<select name=tipo onchange="this.form.tasa.value=DB.cfg.tipos.find(t=>t.n==this.value).t;sim(this.form)">${O(DB.cfg.tipos,t=>`<option>${t.n}</option>`)}</select></label>${L('monto','Monto RD$','','number','required min=1000')}${L('tasa','Tasa mensual %',DB.cfg.tipos[0].t,'number','required step=0.01 min=0')}${L('n','Cuotas (meses)',12,'number','required min=1 max=120')}${L('gar','Garantía / observaciones')}<div id=sim class=sim>Complete el monto para simular.</div><div class=bt><button type=button class=s onclick=X()>Cancelar</button><button>${staff()?'Registrar':'Enviar solicitud'}</button></div></form>`)}
function sim(f){const P=+f.monto.value,t=+f.tasa.value,n=+f.n.value;if(!P||!n)return;const c=cuotaF(P,t,n);$('#sim').innerHTML=`Cuota mensual: <b>${RD(c)}</b> · Total a pagar: <b>${RD(c*n)}</b> · Intereses: <b>${RD(c*n-P)}</b>`}
function sp(ev){const d=fd(ev),P=+d.monto,t=+d.tasa,n=+d.n,c=cli(d.cid);if(P<=0||n<1)return alert('Datos inválidos.');
if(c.ing>0&&cuotaF(P,t,n)>c.ing*.4&&!confirm('La cuota supera el 40% del ingreso mensual del cliente. ¿Continuar?'))return;
const p=nuevoP({cid:d.cid,tipo:d.tipo,monto:P,tasa:t,n,gar:d.gar});log((staff()?'Registró ':'Solicitó ')+p.num);X();lp()}
function ap(id){if(!confirm('¿Aprobar y desembolsar este préstamo hoy?'))return;aprobar(id);lp()}
function rj(id){const m=prompt('Motivo del rechazo:');if(!m)return;const p=DB.prestamos.find(x=>x.id==id);p.estado='Rechazado';p.motivo=m;log('Rechazó '+p.num);save();lp()}
function vp(id){const p=DB.prestamos.find(x=>x.id==id),c=cli(p.cid);M(`<h3>${p.num} · ${e(nom(c))} ${tag(p.estado)}</h3><p>${e(p.tipo)} · ${RD(p.monto)} al ${p.tasa}% mensual · ${p.n} cuotas · Garantía: ${e(p.gar)||'N/A'}<br>Solicitado: ${p.fsol}${p.fdes?' · Desembolsado: '+p.fdes:''}${p.motivo?'<br>Motivo de rechazo: '+e(p.motivo):''}</p>${p.plan.length?T(['#','Vence','Cuota','Interés','Capital','Saldo','Pagado','Mora','Estado'],p.plan.map(x=>[x.n,x.fecha,RD(x.cuota),RD(x.interes),RD(x.capital),RD(x.saldo),RD(x.pag),RD(moraC(x)),x.cuota-x.pag<.005?'Pagada':x.fecha<hoy()?'Atrasada':'Pendiente'])):'<p>Sin tabla de amortización hasta su aprobación.</p>'}<div class=bt><button class=s onclick=X()>Cerrar</button></div>`)}
/* ---- pagos ---- */
V.pagos=()=>`<h2>Pagos</h2>${staff()?`<form class="g card" onsubmit=pg(event)><label>Préstamo activo<select name=pid onchange=ps(this.form)>${O(DB.prestamos.filter(p=>p.estado=='Activo'),p=>`<option value=${p.id}>${p.num} - ${e(nom(cli(p.cid)))}</option>`)}</select></label><label>Método<select name=met><option>Efectivo</option><option>Transferencia</option><option>Tarjeta</option></select></label><div id=pi class=sim></div>${L('monto','Monto a pagar RD$','','number','required step=0.01 min=0.01')}<div class=bt><button>Registrar pago</button></div></form>`:''}<h3>Historial</h3><div id=lst></div>`;
const ps=f=>{const p=DB.prestamos.find(x=>x.id==f.pid.value);if(!p){$('#pi').textContent='No hay préstamos activos.';return}const c=p.plan.find(c=>c.cuota-c.pag>.005),m=morP(p);$('#pi').innerHTML=`Saldo: <b>${RD(sal(p))}</b> · Mora: <b>${RD(m)}</b> · Próxima cuota #${c.n} (${c.fecha}): ${RD(c.cuota-c.pag)}`;f.monto.value=(c.cuota-c.pag+m).toFixed(2)};
const lg=()=>{const f=document.querySelector('#main form');if(f)ps(f);$('#lst').innerHTML=T(['Recibo','Fecha','Préstamo','Cliente','Monto','Incluye mora','Método','Cobró',''],DB.pagos.filter(x=>mine().some(p=>p.id==x.pid)).slice().reverse().map(x=>{const p=DB.prestamos.find(q=>q.id==x.pid);return[x.id,x.f,p.num,e(nom(cli(p.cid))),RD(x.monto),RD(x.mora),x.met,e(x.u),`<button onclick="rc('${x.id}')">Recibo</button>`]}))};
function pg(ev){const d=fd(ev),p=DB.prestamos.find(x=>x.id==d.pid),m=+d.monto;if(!p)return alert('Seleccione un préstamo.');if(m<=0||m>sal(p)+morP(p)+.01)return alert('El monto excede el saldo pendiente más mora ('+RD(sal(p)+morP(p))+').');const x=pagar(p.id,m,d.met);lg();rc(x.id)}
function rc(id){const x=DB.pagos.find(q=>q.id==id),p=DB.prestamos.find(q=>q.id==x.pid);M(`<div class=rec><h3>${e(DB.cfg.empresa)} — Recibo ${x.id}</h3><p>Fecha: ${x.f}<br>Cliente: ${e(nom(cli(p.cid)))}<br>Préstamo: ${p.num}<br>Monto pagado: <b>${RD(x.monto)}</b> (mora incluida: ${RD(x.mora)})<br>Método: ${x.met} · Cobró: ${e(x.u)}<br>Saldo restante: <b>${RD(sal(p))}</b> ${p.estado=='Saldado'?'— PRÉSTAMO SALDADO':''}</p></div><div class=bt><button onclick=print()>Imprimir</button><button class=s onclick=X()>Cerrar</button></div>`)}
/* ---- reportes ---- */
let RPh=[],RPd=[];
V.reportes=()=>`<div class=bar><h2>Reportes</h2><select id=rt onchange=rp()><option value=c>Cartera activa</option><option value=m>Cartera en mora</option><option value=p>Pagos recibidos</option><option value=k>Clientes</option></select>Desde <input type=date id=d1 value=${hoy().slice(0,8)}01 onchange=rp()> Hasta <input type=date id=d2 value=${hoy()} onchange=rp()><button onclick=csv()>Exportar CSV</button><button class=s onclick=print()>Imprimir</button></div><div id=lst></div>`;
function rp(){const t=$('#rt').value,A=DB.prestamos.filter(p=>p.estado=='Activo'),nx=p=>p.plan.find(c=>c.cuota-c.pag>.005);let s='';
if(t=='c'){RPh=['Préstamo','Cliente','Desembolso','Monto','Saldo','Próx. vencimiento'];RPd=A.map(p=>[p.num,nom(cli(p.cid)),p.fdes,RD(p.monto),RD(sal(p)),nx(p).fecha]);s='Cartera total pendiente: '+RD(A.reduce((a,p)=>a+sal(p),0))}
if(t=='m'){const B=A.filter(p=>morP(p)>0);RPh=['Préstamo','Cliente','Teléfono','Cuotas atrasadas','Días de atraso','Capital vencido','Mora'];RPd=B.map(p=>{const v=p.plan.filter(c=>c.cuota-c.pag>.005&&c.fecha<hoy());return[p.num,nom(cli(p.cid)),cli(p.cid).tel,v.length,dias(v[0].fecha),RD(v.reduce((a,c)=>a+c.cuota-c.pag,0)),RD(morP(p))]});s='Mora total: '+RD(B.reduce((a,p)=>a+morP(p),0))}
if(t=='p'){const P=DB.pagos.filter(x=>x.f>=$('#d1').value&&x.f<=$('#d2').value);RPh=['Recibo','Fecha','Préstamo','Cliente','Monto','Mora','Método'];RPd=P.map(x=>{const p=DB.prestamos.find(q=>q.id==x.pid);return[x.id,x.f,p.num,nom(cli(p.cid)),RD(x.monto),RD(x.mora),x.met]});s='Total cobrado: '+RD(P.reduce((a,x)=>a+x.monto,0))}
if(t=='k'){RPh=['Cliente','Cédula','Teléfono','Préstamos','Saldo pendiente'];RPd=DB.clientes.map(c=>[nom(c),c.ced,c.tel,DB.prestamos.filter(p=>p.cid==c.id).length,RD(A.filter(p=>p.cid==c.id).reduce((a,p)=>a+sal(p),0))]);s='Clientes registrados: '+DB.clientes.length}
$('#lst').innerHTML=T(RPh,RPd.map(r=>r.map(e)))+`<p class=tot>${s}</p>`}
function csv(){const t=[RPh,...RPd].map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\n'),a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['\ufeff'+t],{type:'text/csv'}));a.download='reporte_'+hoy()+'.csv';a.click()}
/* ---- configuración ---- */
V.config=()=>`<h2>Configuración</h2><form class="g card" onsubmit=scf(event)><h3>Empresa y parámetros</h3>${L('empresa','Empresa',DB.cfg.empresa)}${L('mora','Mora mensual %',DB.cfg.mora,'number','step=0.01 min=0')}<div class=bt><button>Guardar</button></div></form>
<div class=card><h3>Tipos de préstamo</h3>${T(['Tipo','Tasa mensual %'],DB.cfg.tipos.map(t=>[e(t.n),t.t]))}<form class=bar onsubmit=at(event)>${L('n','Nuevo tipo','','text','required')}${L('t','Tasa %','','number','required step=0.01')}<button>Agregar</button></form></div>
<div class=card><h3>Usuarios</h3>${T(['Nombre','Correo','Rol'],DB.users.map(u=>[e(u.nombre),e(u.email),u.rol]))}<form class=bar onsubmit=au(event)>${L('nombre','Nombre','','text','required')}${L('email','Correo','','email','required')}${L('pass','Contraseña','','password','required minlength=6')}<select name=rol>${O(Object.keys(ROL),r=>`<option>${r}</option>`)}</select><button>Crear usuario</button></form></div>
<div class=card><h3>Respaldo de datos</h3><button onclick=bk()>Descargar respaldo</button> <input type=file accept=.json onchange=rs(this) style="width:auto"> <button class=d onclick=rst()>Restablecer datos de demostración</button></div>
<div class=card><h3>Bitácora de auditoría</h3>${T(['Fecha','Usuario','Acción'],DB.log.slice(0,30).map(l=>[l.f,e(l.u),e(l.a)]))}</div>`;
const scf=ev=>{const d=fd(ev);DB.cfg.empresa=d.empresa;DB.cfg.mora=+d.mora;log('Cambió parámetros');save();alert('Guardado');render()};
const at=ev=>{const d=fd(ev);DB.cfg.tipos.push({n:d.n,t:+d.t});save();render()};
const au=ev=>{const d=fd(ev);if(DB.users.some(u=>u.email==d.email))return alert('Ese correo ya existe.');DB.users.push({nombre:d.nombre,email:d.email,pass:enc(d.pass),rol:d.rol});log('Creó usuario '+d.email);save();render()};
const bk=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(DB)],{type:'application/json'}));a.download='ntl_respaldo_'+hoy()+'.json';a.click()};
const rs=i=>{const r=new FileReader();r.onload=()=>{try{const d=JSON.parse(r.result);if(!d.users||!d.prestamos)throw 0;DB=d;save();alert('Respaldo restaurado');out()}catch{alert('Archivo de respaldo inválido')}};r.readAsText(i.files[0])};
const rst=()=>{if(confirm('Se borrarán todos los datos y se cargarán los de demostración. ¿Continuar?')){seed();out()}};
/* ---- login / registro ---- */
const go=i=>document.querySelectorAll('section').forEach(s=>s.hidden=s.id!=i);let R={};
function login(ev){const d=fd(ev),u=DB.users.find(x=>x.email==d.email.trim().toLowerCase()&&x.pass==enc(d.pass));if(!u)return alert('Correo o contraseña incorrectos.');sessionStorage.ntl_s=u.email;log('Inicio de sesión');location='app.html'}
function r1(ev){R=fd(ev);go('s2')}
function r2(ev){const m=fd(ev).email.trim().toLowerCase();if(DB.users.some(u=>u.email==m))return alert('Ese correo ya está registrado.');R.email=m;go('s3')}
function r3(ev){const d=fd(ev);if(d.p1!=d.p2)return alert('Las contraseñas no coinciden.');DB.users.push({nombre:R.nombre+' '+R.apellido,email:R.email,pass:enc(d.p1),rol:'Cliente'});
if(!DB.clientes.some(c=>c.email==R.email))DB.clientes.push({id:gid('c'),nombre:R.nombre,apellido:R.apellido,email:R.email,ced:'',tel:'',dir:'',ocup:'',ing:0,gar:'',fecha:hoy()});save();alert('¡Registro completado! Ya puede iniciar sesión.');go('s0')}
function rec(ev){const d=fd(ev),u=DB.users.find(x=>x.email==d.email.trim().toLowerCase());if(!u)return alert('No existe una cuenta con ese correo.');u.pass=enc(d.pass);save();alert('Contraseña actualizada.');go('s0')}
$('#nav')?initApp():0;
